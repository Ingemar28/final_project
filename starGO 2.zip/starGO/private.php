<?php
$mysql_user = "dbExample";
$mysql_pass = "deco18007180";
?>