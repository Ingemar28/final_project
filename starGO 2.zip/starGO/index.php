<?php
require_once 'mysql.php';
require_once 'private.php';
require_once 'util.php';
require_once 'queries.php';
$parks_url = "https://www.data.brisbane.qld.gov.au/data/api/3/action/datastore_search";
?>

